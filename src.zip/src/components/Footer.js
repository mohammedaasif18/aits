function Footer(){
    return(
        <div>
            <h1 className="Footer"> Footer</h1>
        </div>
        );
}
export default Footer;