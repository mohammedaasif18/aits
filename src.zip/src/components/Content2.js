function Content2(){
    return(
        <div>
            <h1 className="Content2"> Content2</h1>
        </div>
        );
}
export default Content2;