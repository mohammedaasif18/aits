function Content1(){
    return(
        <div>
            <h1 className="Content1"> Content1</h1>
        </div>
        );
}
export default Content1;